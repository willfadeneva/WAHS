# WAHS + Congress 2026 — Full Structure & Flow

> Local-only doc. Not committed to git.

---

## Stack

| Layer | Tech |
|-------|------|
| Framework | Next.js 14.2 (App Router) |
| Auth | Supabase Auth (magic link + email/password) |
| DB | Supabase Postgres (RLS enabled) |
| Email | Resend |
| Payments | PayPal direct links (no webhooks) |
| Hosting | Vercel (auto-deploy from `main`) |
| Domain | `congress.iwahs.org` → Vercel |
| Repo | `github.com/willfadeneva/WAHS` via SSH alias `github-wahs` |

---

## Directory Structure

```
src/
├── app/
│   ├── layout.tsx                  # Root layout (fonts, globals.css)
│   ├── page.tsx                    # Homepage (WAHS main site)
│   ├── not-found.tsx               # Custom 404
│   ├── globals.css
│
│   ├── about/page.tsx              # About WAHS
│   ├── membership/page.tsx         # Join WAHS page
│
│   ├── auth/
│   │   ├── callback/route.ts       # Supabase auth callback (handles magic links)
│   │   └── reset-password/page.tsx
│
│   ├── wahs/                       # WAHS member auth flows
│   │   ├── login/page.tsx          # Login (+ dues_pending warning + redirect param)
│   │   ├── register/page.tsx       # Join / create account
│   │   ├── forgot-password/page.tsx
│   │   ├── dashboard/page.tsx      # Member dashboard
│   │   ├── members/page.tsx        # Member directory
│   │   ├── profile/page.tsx        # Edit profile
│   │   ├── resources/page.tsx      # Member resources
│   │   └── payment/success/page.tsx # After PayPal dues payment
│
│   ├── congress/[year]/            # Congress pages (dynamic by year)
│   │   ├── page.tsx                # Congress homepage (fetches from Supabase)
│   │   ├── layout.tsx              # Minimal passthrough layout
│   │   ├── login/page.tsx          # Congress account login (dues check → redirect)
│   │   ├── register/page.tsx       # Create congress account
│   │   ├── dashboard/page.tsx      # Submission dashboard (auth-guarded)
│   │   ├── submit-abstract/page.tsx # Submit form (auth-guarded)
│   │   ├── registration/           # Congress registration + PayPal
│   │   │   ├── page.tsx
│   │   │   └── WAHSMemberRegistration.tsx
│   │   ├── submissions/
│   │   │   ├── page.tsx            # CFP info page (SubmissionCTA component)
│   │   │   └── [id]/edit/page.tsx  # Edit submission (auth-guarded)
│   │   ├── board-members/page.tsx
│   │   ├── history/page.tsx
│   │   └── past-congresses/page.tsx
│
│   ├── admin/                      # Admin dashboard (magic-link only)
│   │   ├── login/page.tsx          # Admin login (footer ghost link only)
│   │   ├── page.tsx                # Admin overview
│   │   └── AdminDashboard.tsx
│
│   └── api/
│       ├── congress/[year]/
│       │   ├── register/route.ts   # Congress registration API
│       │   └── submissions/route.ts
│       ├── [year]/                 # Alt API routes (same handlers)
│       │   ├── register/route.ts
│       │   └── submissions/route.ts
│       ├── admin/
│       │   ├── members/route.ts
│       │   ├── speakers/route.ts
│       │   └── submissions/route.ts
│       ├── members/
│       │   ├── route.ts
│       │   └── [id]/route.ts
│       ├── registrations/
│       │   ├── route.ts
│       │   ├── [id]/route.ts
│       │   └── check/route.ts
│       ├── submissions/route.ts
│       └── wahs/register/route.ts
│
├── components/
│   ├── Nav.tsx                     # Congress-aware nav (used on congress/[year] pages)
│   ├── CongressNav.tsx             # Minimal nav for congress auth pages (login/dashboard/etc)
│   ├── MainNav.tsx                 # WAHS main site nav
│   ├── Footer.tsx                  # Congress footer (contact + address + admin link)
│   ├── MainFooter.tsx              # WAHS main footer (+ Quick Links)
│   ├── Hero.tsx                    # Congress hero banner
│   ├── Overview.tsx                # Congress overview section
│   ├── Speakers.tsx                # Keynote + plenary speaker cards
│   ├── Tracks.tsx                  # Congress tracks
│   ├── Timeline.tsx                # Key dates
│   ├── Venue.tsx                   # Venue info
│   ├── Publications.tsx            # Publications section
│   ├── CTA.tsx                     # Register CTA banner
│   ├── Registration.tsx            # Dual pricing cards + 3-step PayPal flow
│   ├── SubmissionCTA.tsx           # Auth-aware CFP call to action
│   ├── SubmissionForm.tsx          # (legacy, replaced by SubmissionCTA on CFP page)
│   ├── Submissions.tsx             # CFP page wrapper
│   ├── Breadcrumbs.tsx
│   ├── ScrollReveal.tsx
│   ├── Committee.tsx
│   ├── Congress2022.tsx            # Static archive for 2022 congress
│   └── ...
│
├── lib/
│   ├── supabase.ts                 # Browser Supabase client
│   ├── supabase-server.ts          # Server-side Supabase client
│   ├── paypal.ts                   # PayPal link builder + isEarlyBird()
│   └── email.ts                    # Resend email helpers
│
└── middleware.ts                   # Auth protection for congress + wahs + admin routes
```

---

## Auth Architecture

### Two separate account types, one `auth.users` table

| Account Type | Entry Point | Table |
|---|---|---|
| WAHS Member | `/wahs/login` | `wahs_members` |
| Congress Submitter | `/congress/[year]/login` | `congress_registrations` |
| Admin | `/admin/login` (footer only) | `admin_users` |

All use Supabase Auth under the hood (`auth.users`).

---

## Congress Auth Flow

```
/congress/2026/login
  │
  ├─ Not a WAHS member? → Normal congress login
  │
  └─ WAHS member with dues_pending?
       → signOut()
       → redirect /wahs/login?dues_pending=1&redirect=/2026/dashboard
            │
            └─ After paying dues → redirect back to /2026/dashboard
```

### Middleware Protection

```ts
CONGRESS_AUTH_RE = /^\/(\\d{4})\/(dashboard|submit-abstract|submissions\/.+\/edit)/
```

Protected paths:
- `/:year/dashboard`
- `/:year/submit-abstract`
- `/:year/submissions/:id/edit`
- `/wahs/:path*`
- `/admin/:path*` (except `/admin/login`)

---

## Registration & Payment Flow

```
/congress/2026/registration
  │
  ├─ Step 1: Choose tier (Early Bird / Regular / Student)
  │          Both prices always shown; inactive = strikethrough
  │          Early bird auto-switches via isEarlyBird() after 2026-05-15T23:59:59+09:00
  │
  ├─ Step 2: Fill registration form
  │
  └─ Step 3: PayPal button → external PayPal page
               No webhook. Payment confirmation is manual/email-based.

WAHS members with active dues → free registration (noted on cards)
WAHS members with pending dues → redirected to pay first
```

### PayPal Link IDs

| Tier | Early Bird | Full Price |
|------|-----------|------------|
| Regular | `5HCS2HYEPSTSG` | `GWYKZDB2TBXRC` |
| Student | `69333BMBXNTUE` | `FCVG73FR3RELG` |
| WAHS Professional | `9K9JC2CZ6N7S2` | — |
| WAHS Student | `Y2V33KK92X5SU` | — |

---

## Abstract Submission Flow

```
/congress/2026/submissions   ← CFP info page (SubmissionCTA)
  │
  ├─ Logged out → Sign In + Create Account buttons
  │
  └─ Logged in → Submit Abstract (/2026/submit-abstract)
                  My Dashboard (/2026/dashboard)

/congress/2026/submit-abstract  ← guarded by middleware
  └─ On submit → POST /api/[year]/submissions
                 → email confirmation via Resend

/congress/2026/dashboard  ← guarded by middleware
  └─ Lists user's submissions
     └─ Edit → /congress/[year]/submissions/[id]/edit
```

---

## Database Tables

| Table | Purpose |
|-------|---------|
| `congresses` | One row per year; stores title, dates, venue, deadlines |
| `speakers` | Per-congress; `is_plenary=false` = keynote, `is_plenary=true` = plenary panel |
| `wahs_members` | WAHS membership profiles; `membership_status`, `dues_paid_until` |
| `congress_registrations` | Per-year registrations; links to `auth.users` |
| `submissions` | Abstract submissions; links to `congress_registrations` |
| `admin_users` | Allowlist for admin access (`oingyu@gmail.com`, `charanjotsingh@gmail.com`) |

RLS is enabled on all tables.

---

## Speakers

| Name | Role | `is_plenary` |
|------|------|-------------|
| Henry Jenkins | USC | `false` (keynote) |
| Jieun Kiaer | Oxford | `false` (keynote) |
| Roald Maliangkay | ANU | `false` (keynote) |
| Ingyu Oh | Kansai Gaidai | `false` (keynote) |
| Rob Kutner | 5× Emmy writer | `true` (plenary panel) |
| Marlene Sharp | Producer | `true` (plenary panel) |

Photos at `/public/speakers/[slug].jpg`. Kutner + Sharp use `objectPosition: 'center 25%'`.

---

## Key Dates (Hardcoded)

| Event | Value |
|-------|-------|
| Early bird deadline | `2026-05-15T23:59:59+09:00` |
| Congress dates | May 28–30, 2026 |
| Location | Jeju Island, South Korea |

---

## Environment Variables

| Key | Where set |
|-----|-----------|
| `NEXT_PUBLIC_SUPABASE_URL` | `https://gqroifralqsvrcuywfcr.supabase.co` |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Supabase anon JWT |
| `SUPABASE_SERVICE_ROLE_KEY` | Supabase service role JWT |
| `DATABASE_URL` | Direct Postgres connection string |
| `RESEND_API_KEY` | Resend email API key |
| `NEXT_PUBLIC_SITE_URL` | `https://congress.iwahs.org` (prod) / `http://localhost:3000` (local) |
| `NEXT_PUBLIC_PAYPAL_*` | PayPal link URLs |
| `NEXT_PUBLIC_CONGRESS_EARLYBIRD_DEADLINE` | `2026-05-15` |
| `NEXT_PUBLIC_ADMIN_EMAILS` | `oingyu@gmail.com,charanjotsingh@gmail.com` |

Local: `.env.local` — never committed.
Production: Vercel dashboard → Settings → Environment Variables.

---

## Deployment

```
git push git@github-wahs:willfadeneva/WAHS.git main
  └─ Vercel auto-deploys → congress.iwahs.org + wahs.vercel.app
```

SSH key: `~/.ssh/wahs_deploy` via `~/.ssh/config` alias `github-wahs`.

Local dev: `npm run dev` on port 3000 (IP: `100.105.236.97` / `76.13.241.238`).

---

## Nav & Footer Rules

- **Admin link:** Footer only (ghost/discreet). Never in any nav.
- **"Register & Pay":** Replaced everywhere with "Register".
- **Footer layout:** Two columns (Contact Info left, Address right), divider, centered WAHS branding. CJ credit → `wa.me/818042615062`. WAHS WhatsApp → `wa.me/8229715577`.
- **CongressNav:** Used on congress auth pages (`login`, `register`, `dashboard`, `submit-abstract`, `submissions/[id]/edit`). Accepts `year: string | number`.
